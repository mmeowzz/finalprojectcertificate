﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace COCO
{
    public partial class DELETE : Form
    {
        public DELETE()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlCommand cmd;

        private void btn_gallery_Click(object sender, EventArgs e)
        {
            GALLERY obj = new GALLERY();
            obj.Show();
        }

        private void btn_home_Click(object sender, EventArgs e)
        {
            HOME_PAGE obj = new HOME_PAGE();
            obj.Show();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            LOGIN obj = new LOGIN();
            obj.Show();
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            REGISTRATION obj = new REGISTRATION();
            obj.Show();
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            UPDATE obj = new UPDATE();
            obj.Show();
        }

        private void btn_display_Click(object sender, EventArgs e)
        {
            DISPLAY obj = new DISPLAY();
            obj.Show();
        }

        private void btn_wage_Click(object sender, EventArgs e)
        {
            WAGE obj = new WAGE();
            obj.Show();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            SEARCH obj = new SEARCH();
            obj.Show();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DELETE obj = new DELETE();
            obj.Show();
        }

        private void DELETE_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=desktop-g85uqsh;Initial Catalog=COCO;Integrated Security=True");
        }

        private void btn_del_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand("Delete from Register where Employee_ID = '"+txt_id.Text+"'",con);
            int i = cmd.ExecuteNonQuery();
            if (i == 1)
                MessageBox.Show("Data deleted successfully.","Information",MessageBoxButtons.OK,MessageBoxIcon.Information);
            else
                MessageBox.Show("Data cannot be deleted.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            con.Close();
        }

       
    }
}
