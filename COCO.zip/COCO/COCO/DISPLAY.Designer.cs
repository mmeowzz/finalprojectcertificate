﻿namespace COCO
{
    partial class DISPLAY
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_login = new System.Windows.Forms.Button();
            this.btn_register = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_display = new System.Windows.Forms.Button();
            this.btn_wage = new System.Windows.Forms.Button();
            this.btn_search = new System.Windows.Forms.Button();
            this.btn_home = new System.Windows.Forms.Button();
            this.btn_gallery = new System.Windows.Forms.Button();
            this.date_table = new System.Windows.Forms.DataGridView();
            this.btn_dis = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.date_table)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.Color.Lavender;
            this.btn_delete.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_delete.Location = new System.Drawing.Point(12, 459);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(147, 47);
            this.btn_delete.TabIndex = 23;
            this.btn_delete.Text = "DELETE";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_login
            // 
            this.btn_login.BackColor = System.Drawing.Color.Lavender;
            this.btn_login.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_login.Location = new System.Drawing.Point(12, 203);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(147, 47);
            this.btn_login.TabIndex = 21;
            this.btn_login.Text = "LOGIN";
            this.btn_login.UseVisualStyleBackColor = false;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // btn_register
            // 
            this.btn_register.BackColor = System.Drawing.Color.Lavender;
            this.btn_register.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_register.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_register.Location = new System.Drawing.Point(12, 138);
            this.btn_register.Name = "btn_register";
            this.btn_register.Size = new System.Drawing.Size(147, 47);
            this.btn_register.TabIndex = 20;
            this.btn_register.Text = "REGISTER";
            this.btn_register.UseVisualStyleBackColor = false;
            this.btn_register.Click += new System.EventHandler(this.btn_register_Click);
            // 
            // btn_update
            // 
            this.btn_update.BackColor = System.Drawing.Color.Lavender;
            this.btn_update.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_update.Location = new System.Drawing.Point(12, 396);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(147, 47);
            this.btn_update.TabIndex = 19;
            this.btn_update.Text = "UPDATE";
            this.btn_update.UseVisualStyleBackColor = false;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_display
            // 
            this.btn_display.BackColor = System.Drawing.Color.Lavender;
            this.btn_display.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_display.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_display.Location = new System.Drawing.Point(12, 333);
            this.btn_display.Name = "btn_display";
            this.btn_display.Size = new System.Drawing.Size(147, 47);
            this.btn_display.TabIndex = 18;
            this.btn_display.Text = "DISPLAY";
            this.btn_display.UseVisualStyleBackColor = false;
            this.btn_display.Click += new System.EventHandler(this.btn_display_Click);
            // 
            // btn_wage
            // 
            this.btn_wage.BackColor = System.Drawing.Color.Lavender;
            this.btn_wage.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_wage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_wage.Location = new System.Drawing.Point(12, 267);
            this.btn_wage.Name = "btn_wage";
            this.btn_wage.Size = new System.Drawing.Size(147, 47);
            this.btn_wage.TabIndex = 17;
            this.btn_wage.Text = "WAGES";
            this.btn_wage.UseVisualStyleBackColor = false;
            this.btn_wage.Click += new System.EventHandler(this.btn_wage_Click);
            // 
            // btn_search
            // 
            this.btn_search.BackColor = System.Drawing.Color.Lavender;
            this.btn_search.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_search.Location = new System.Drawing.Point(12, 75);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(147, 47);
            this.btn_search.TabIndex = 16;
            this.btn_search.Text = "SEARCH";
            this.btn_search.UseVisualStyleBackColor = false;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // btn_home
            // 
            this.btn_home.BackColor = System.Drawing.Color.Lavender;
            this.btn_home.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_home.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_home.Location = new System.Drawing.Point(12, 12);
            this.btn_home.Name = "btn_home";
            this.btn_home.Size = new System.Drawing.Size(147, 47);
            this.btn_home.TabIndex = 15;
            this.btn_home.Text = "HOME";
            this.btn_home.UseVisualStyleBackColor = false;
            this.btn_home.Click += new System.EventHandler(this.btn_home_Click);
            // 
            // btn_gallery
            // 
            this.btn_gallery.BackColor = System.Drawing.Color.Lavender;
            this.btn_gallery.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_gallery.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_gallery.Location = new System.Drawing.Point(12, 521);
            this.btn_gallery.Name = "btn_gallery";
            this.btn_gallery.Size = new System.Drawing.Size(147, 47);
            this.btn_gallery.TabIndex = 25;
            this.btn_gallery.Text = "GALLERY";
            this.btn_gallery.UseVisualStyleBackColor = false;
            this.btn_gallery.Click += new System.EventHandler(this.btn_gallery_Click);
            // 
            // date_table
            // 
            this.date_table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.date_table.Location = new System.Drawing.Point(183, 187);
            this.date_table.Name = "date_table";
            this.date_table.RowHeadersWidth = 51;
            this.date_table.RowTemplate.Height = 24;
            this.date_table.Size = new System.Drawing.Size(1059, 335);
            this.date_table.TabIndex = 26;
            // 
            // btn_dis
            // 
            this.btn_dis.BackColor = System.Drawing.Color.Lavender;
            this.btn_dis.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_dis.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_dis.Location = new System.Drawing.Point(1111, 528);
            this.btn_dis.Name = "btn_dis";
            this.btn_dis.Size = new System.Drawing.Size(131, 40);
            this.btn_dis.TabIndex = 27;
            this.btn_dis.Text = "Dispay Table";
            this.btn_dis.UseVisualStyleBackColor = false;
            this.btn_dis.Click += new System.EventHandler(this.btn_dis_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(602, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(388, 30);
            this.label2.TabIndex = 29;
            this.label2.Text = "Beauty Lies Within You...";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MV Boli", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Purple;
            this.label1.Location = new System.Drawing.Point(580, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(662, 105);
            this.label1.TabIndex = 28;
            this.label1.Text = "COCO Cosmetics";
            // 
            // DISPLAY
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1260, 588);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_dis);
            this.Controls.Add(this.date_table);
            this.Controls.Add(this.btn_gallery);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.btn_register);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_display);
            this.Controls.Add(this.btn_wage);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.btn_home);
            this.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Name = "DISPLAY";
            this.Text = "DISPLAY";
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
            this.Load += new System.EventHandler(this.DISPLAY_Load);
            ((System.ComponentModel.ISupportInitialize)(this.date_table)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button btn_register;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_display;
        private System.Windows.Forms.Button btn_wage;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Button btn_home;
        private System.Windows.Forms.Button btn_gallery;
        private System.Windows.Forms.DataGridView date_table;
        private System.Windows.Forms.Button btn_dis;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}