﻿namespace COCO
{
    partial class GALLERY
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GALLERY));
            this.list_img = new System.Windows.Forms.ImageList(this.components);
            this.box_picture = new System.Windows.Forms.PictureBox();
            this.previous = new System.Windows.Forms.Button();
            this.next = new System.Windows.Forms.Button();
            this.lbl_img = new System.Windows.Forms.Label();
            this.lbl_number = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.box_picture)).BeginInit();
            this.SuspendLayout();
            // 
            // list_img
            // 
            this.list_img.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("list_img.ImageStream")));
            this.list_img.TransparentColor = System.Drawing.Color.Transparent;
            this.list_img.Images.SetKeyName(0, "Get the We Heart It app! (3).jpeg");
            this.list_img.Images.SetKeyName(1, "Get the We Heart It app! (2).jpeg");
            this.list_img.Images.SetKeyName(2, "This Iridescent Highlighter Will Convince You That the Mystical Trend Is Still Al" +
        "ive.jpeg");
            this.list_img.Images.SetKeyName(3, "Image about fashion in ♕♣ ℋ ℴ ℘ ℯ l ℯ હ હ ♣\'S_Make_Up♕ by ℋ ℴ ℘ ℯ l ℯ હ હ.jpeg");
            this.list_img.Images.SetKeyName(4, "4ee2d8d0-577d-41c3-99e1-7e880c7e75c4.jpeg");
            this.list_img.Images.SetKeyName(5, "Get the We Heart It app! (1).jpeg");
            this.list_img.Images.SetKeyName(6, "58ea3c0e-6d64-45c8-9a4a-d728ed6ce0fb.jpeg");
            this.list_img.Images.SetKeyName(7, "Faves from Charlotte Tilbury (Mapped Out Blog).jpeg");
            this.list_img.Images.SetKeyName(8, "The Prettiest Blush on Pinterest Is Made With Rose Petals.jpeg");
            this.list_img.Images.SetKeyName(9, "How to Contour in 3 Easy Steps.jpeg");
            this.list_img.Images.SetKeyName(10, "What\'s in My Makeup Bag_ March.jpeg");
            this.list_img.Images.SetKeyName(11, "38441615-f17f-4636-ac57-8a6850e05e75.jpeg");
            this.list_img.Images.SetKeyName(12, "WORK _ Studio Say Creative.jpeg");
            this.list_img.Images.SetKeyName(13, "Alter Ego Sahara Palette - Product Photography by Brianna Levay.jpeg");
            this.list_img.Images.SetKeyName(14, "Come for the cuteness, stay for the pigmentation & blendable formula 💖.jpeg");
            this.list_img.Images.SetKeyName(15, "The Eyeshadow Palette For Your Ultimate Warm-Toned Look (Diane Elizabeth).jpeg");
            this.list_img.Images.SetKeyName(16, "Cosmetic Texture - Product Photography by Brianna Levay.jpeg");
            this.list_img.Images.SetKeyName(17, "\'HYPNOTISM\' _ L\'OFFICIEL Baltics.jpeg");
            this.list_img.Images.SetKeyName(18, "Jacky Wruck GNTM 2020 Beauty Shooting by Mona Strieder __ Agency_ ONE eins fab.jp" +
        "eg");
            this.list_img.Images.SetKeyName(19, "BFF Collection Page - Phase 2.jpeg");
            this.list_img.Images.SetKeyName(20, "Charlotte Tilbury Pillow Talk Collection - Makeup-Sessions.jpeg");
            this.list_img.Images.SetKeyName(21, "e244e0dc-d6b7-46c7-b515-5c36cf4d8d75.jpeg");
            this.list_img.Images.SetKeyName(22, "Work by Iwona Grabowska, Iza Ambroziak.jpeg");
            this.list_img.Images.SetKeyName(23, "Top 23 Product Photography Ideas.jpeg");
            this.list_img.Images.SetKeyName(24, "Stunning 😍.jpeg");
            // 
            // box_picture
            // 
            this.box_picture.Location = new System.Drawing.Point(64, 101);
            this.box_picture.Name = "box_picture";
            this.box_picture.Size = new System.Drawing.Size(256, 256);
            this.box_picture.TabIndex = 0;
            this.box_picture.TabStop = false;
            // 
            // previous
            // 
            this.previous.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.previous.Location = new System.Drawing.Point(64, 375);
            this.previous.Name = "previous";
            this.previous.Size = new System.Drawing.Size(86, 50);
            this.previous.TabIndex = 1;
            this.previous.Text = "<";
            this.previous.UseVisualStyleBackColor = true;
            this.previous.Click += new System.EventHandler(this.previous_Click);
            // 
            // next
            // 
            this.next.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.next.Location = new System.Drawing.Point(234, 375);
            this.next.Name = "next";
            this.next.Size = new System.Drawing.Size(86, 50);
            this.next.TabIndex = 2;
            this.next.Text = ">";
            this.next.UseVisualStyleBackColor = true;
            this.next.Click += new System.EventHandler(this.next_Click);
            // 
            // lbl_img
            // 
            this.lbl_img.AutoSize = true;
            this.lbl_img.Location = new System.Drawing.Point(61, 441);
            this.lbl_img.Name = "lbl_img";
            this.lbl_img.Size = new System.Drawing.Size(80, 16);
            this.lbl_img.TabIndex = 3;
            this.lbl_img.Text = "Image Index";
            // 
            // lbl_number
            // 
            this.lbl_number.AutoSize = true;
            this.lbl_number.Location = new System.Drawing.Point(158, 441);
            this.lbl_number.Name = "lbl_number";
            this.lbl_number.Size = new System.Drawing.Size(11, 16);
            this.lbl_number.TabIndex = 4;
            this.lbl_number.Text = "-";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(29, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(259, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "Beauty Lies Within You...";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MV Boli", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Purple;
            this.label1.Location = new System.Drawing.Point(24, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(341, 52);
            this.label1.TabIndex = 8;
            this.label1.Text = "COCO Cosmetics";
            // 
            // GALLERY
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(388, 473);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_number);
            this.Controls.Add(this.lbl_img);
            this.Controls.Add(this.next);
            this.Controls.Add(this.previous);
            this.Controls.Add(this.box_picture);
            this.Name = "GALLERY";
            this.Text = "COCO GALLERY";
            ((System.ComponentModel.ISupportInitialize)(this.box_picture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ImageList list_img;
        private System.Windows.Forms.PictureBox box_picture;
        private System.Windows.Forms.Button previous;
        private System.Windows.Forms.Button next;
        private System.Windows.Forms.Label lbl_img;
        private System.Windows.Forms.Label lbl_number;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}