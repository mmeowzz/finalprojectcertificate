﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COCO
{
    public partial class GALLERY : Form
    {
        public GALLERY()
        {
            InitializeComponent();
        }
        int count = -1;
        private void next_Click(object sender, EventArgs e)
        {
            if (count < 24)
            {
                count++;
            }
            lbl_number.Text = (count+1).ToString(); 
            box_picture.Image = list_img.Images[count];
        }

        private void previous_Click(object sender, EventArgs e)
        {
            if (count > 0)
            {
                count--;
            }
            lbl_number.Text = (count + 1).ToString();
            box_picture.Image = list_img.Images[count];
        }
    }
}
