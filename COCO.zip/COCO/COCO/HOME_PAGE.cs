﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COCO
{
    public partial class HOME_PAGE : Form
    {
        public HOME_PAGE()
        {
            InitializeComponent();
        }

        private void HOME_PAGE_Load(object sender, EventArgs e)
        {
            //
        }

        private void btn_home_Click(object sender, EventArgs e)
        {
            HOME_PAGE obj = new HOME_PAGE();
            obj.Show();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            SEARCH obj = new SEARCH();
            obj.Show();
        }

        private void btn_wage_Click(object sender, EventArgs e)
        {
            WAGE obj = new WAGE();
            obj.Show();
        }

        private void btn_display_Click(object sender, EventArgs e)
        {
            DISPLAY obj = new DISPLAY();
            obj.Show();
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            UPDATE obj = new UPDATE();
            obj.Show();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DELETE obj = new DELETE();
            obj.Show();
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            REGISTRATION obj = new REGISTRATION();
            obj.Show();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            LOGIN obj = new LOGIN();
            obj.Show();
        }

        private void btn_gallery_Click(object sender, EventArgs e)
        {
            GALLERY obj = new GALLERY();
            obj.Show();
        }
        private string user_name; //existing code
        public string Username //set username property
        {
            get { return user_name; }
            set
            {
                user_name = value;
                //user_name variable can be used in the form
                lbl_welcome.Text = "Welcome, " + user_name + "!";
            }
        }
    }
}
