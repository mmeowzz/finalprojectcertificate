﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;

namespace COCO
{
    public partial class LOGIN : Form
    {
        public LOGIN()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        private string Username;

        private void btn_gallery_Click(object sender, EventArgs e)
        {
            GALLERY obj = new GALLERY();
            obj.Show();
        }

        private void btn_home_Click(object sender, EventArgs e)
        {
            HOME_PAGE obj = new HOME_PAGE();
            obj.Show();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            LOGIN obj = new LOGIN();
            obj.Show();
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            REGISTRATION obj = new REGISTRATION();
            obj.Show();
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            UPDATE obj = new UPDATE();
            obj.Show();
        }

        private void btn_display_Click(object sender, EventArgs e)
        {
            DISPLAY obj = new DISPLAY();
            obj.Show();
        }

        private void btn_wage_Click(object sender, EventArgs e)
        {
            WAGE obj = new WAGE();
            obj.Show();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            SEARCH obj = new SEARCH();
            obj.Show();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DELETE obj = new DELETE();
            obj.Show();
        }

        private void LOGIN_Load(object sender, EventArgs e)
        {
            panel1.BackColor = Color.FromArgb(100, 0, 0, 0);
            btn_sign.Click += btn_sign_Click;
            btn_log.Click += btn_log_Click;

            con = new SqlConnection("Data Source=desktop-g85uqsh;Initial Catalog=COCO;Integrated Security=True");
            con.Open();
        }

        private void btn_sign_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Button Clicked");
            try
            {
                this.Hide();
                SIGNUP obj = new SIGNUP();
                obj.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_log_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Button Clicked");
            try
            {
                if (txt_pswd.Text != string.Empty || txt_user.Text != string.Empty)
                {
                    cmd = new SqlCommand("Select * from SignUp where Username = '" + txt_user.Text + "' and User_Password = '" + txt_pswd.Text + "'", con);
                    dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        dr.Close();
                        MessageBox.Show("Logged in successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                        HOME_PAGE home = new HOME_PAGE();
                        home.Username = txt_user.Text; //set username property
                        home.Show();
                    }
                    else
                    {
                        dr.Close();
                        MessageBox.Show("Account unavailable.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please all the fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btn_log_Click_1(object sender, EventArgs e)
        {

        }

        private void link_show_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (link_show.Text == "Show")
            {
                txt_pswd.PasswordChar = '\0';
                link_show.Text = "Hide";
            }
            else
            {
                txt_pswd.PasswordChar = '*';
                link_show.Text = "Show";
            }
        }
    }
}
