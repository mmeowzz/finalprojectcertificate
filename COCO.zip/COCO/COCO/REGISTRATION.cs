﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Reflection.Emit;
using System.Net.Mail;
using System.Net;

namespace COCO
{
    public partial class REGISTRATION : Form
    {
        public REGISTRATION()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlCommand cmd;

        private void btn_home_Click(object sender, EventArgs e)
        {
            HOME_PAGE obj = new HOME_PAGE();
            obj.Show();
        }

        private void btn_signup_Click(object sender, EventArgs e)
        {
            SIGNUP obj = new SIGNUP();
            obj.Show();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            LOGIN obj = new LOGIN();
            obj.Show();
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            REGISTRATION obj = new REGISTRATION();
            obj.Show();
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            UPDATE obj = new UPDATE();
            obj.Show();
        }

        private void btn_display_Click(object sender, EventArgs e)
        {
            DISPLAY obj = new DISPLAY();
            obj.Show();
        }

        private void btn_wage_Click(object sender, EventArgs e)
        {
            WAGE obj = new WAGE();
            obj.Show();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            SEARCH obj = new SEARCH();
            obj.Show();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DELETE obj = new DELETE();
            obj.Show();
        }

        private void btn_gallery_Click(object sender, EventArgs e)
        {
            GALLERY obj = new GALLERY();
            obj.Show();
        }
        private void REGISTRATION_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=desktop-g85uqsh;Initial Catalog=COCO;Integrated Security=True");
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            string g;
            if (rbtn_male.Checked == true)
            {
                g = "Male";
            }
            else
            {
                g = "Female";
            }
            try
            {
                con.Open();
                cmd = new SqlCommand("Insert into Register values ('" + txt_name.Text + "','" + txt_nic.Text + "','" + g + "','" + txt_address.Text + "','" + datetimepicker.Value + "','" + txt_age.Text + "','" + txt_contact.Text + "','" + cmb_job.SelectedItem + "','" + txt_email.Text + "')", con);

                if (txt_name.Text.Length == 0 || txt_name.Text.Any(char.IsDigit))
                    MessageBox.Show("Name cannot be blank or has numbers.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                else if (txt_nic.Text.Length == 0)
                    MessageBox.Show("NIC cannot be blank.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                else if (rbtn_male.Checked == false & rbtn_female.Checked == false)
                    MessageBox.Show("Please select gender.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                else if (txt_address.Text.Length == 0)
                    MessageBox.Show("Address cannot be blank.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                else if (Convert.ToInt32(txt_age.Text) < 21 || Convert.ToInt32(txt_age.Text) > 55)
                    MessageBox.Show("Staff members should be between age 21 - 55.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                else if (!Regex.IsMatch(txt_contact.Text, @"^7|0|((?:\+94))[0-9]{8,9}$"))
                    MessageBox.Show("Contact Number should have 10 digits.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                else if (cmb_job.SelectedIndex <= -1)
                    MessageBox.Show("Please select job postion.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                else if (txt_email.Text.Length == 0)
                    MessageBox.Show("Email cannot be blank.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                else
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Registered Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
            }
             //cmd.ExecuteNonQuery();
            //con.Close();
        }
        

        private void datetimepicker_ValueChanged(object sender, EventArgs e)
        {
            int age = DateTime.Now.Year - datetimepicker.Value.Year;
            txt_age.Text = age.ToString();
        }

        
            private void txt_id_TextChanged(object sender, EventArgs e)
        {
            //
        }

        private void clear_Click(object sender, EventArgs e)
        {
            txt_name.Clear();
            txt_nic.Clear();
            rbtn_male.Checked = false;
            rbtn_female.Checked = false;
            txt_address.Clear();
            datetimepicker.ResetText();
            txt_age.Clear();
            txt_contact.Clear();
            cmb_job.SelectedIndex=-1;
            txt_email.Clear();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            //
        }
    }
}
