﻿namespace COCO
{
    partial class SIGNUP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SIGNUP));
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_login = new System.Windows.Forms.Button();
            this.btn_register = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_display = new System.Windows.Forms.Button();
            this.btn_wage = new System.Windows.Forms.Button();
            this.btn_search = new System.Windows.Forms.Button();
            this.btn_home = new System.Windows.Forms.Button();
            this.btn_gallery = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.link_show = new System.Windows.Forms.LinkLabel();
            this.btn_sign = new System.Windows.Forms.Button();
            this.lbl_user = new System.Windows.Forms.Label();
            this.btn_log = new System.Windows.Forms.Button();
            this.txt_user = new System.Windows.Forms.TextBox();
            this.txt_confirm = new System.Windows.Forms.TextBox();
            this.txt_pswd = new System.Windows.Forms.TextBox();
            this.lbl_confirm = new System.Windows.Forms.Label();
            this.lbl_pswd = new System.Windows.Forms.Label();
            this.link_show2 = new System.Windows.Forms.LinkLabel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.Color.Lavender;
            this.btn_delete.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_delete.Location = new System.Drawing.Point(12, 460);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(147, 47);
            this.btn_delete.TabIndex = 31;
            this.btn_delete.Text = "DELETE";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_login
            // 
            this.btn_login.BackColor = System.Drawing.Color.Lavender;
            this.btn_login.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_login.Location = new System.Drawing.Point(12, 204);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(147, 47);
            this.btn_login.TabIndex = 30;
            this.btn_login.Text = "LOGIN";
            this.btn_login.UseVisualStyleBackColor = false;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // btn_register
            // 
            this.btn_register.BackColor = System.Drawing.Color.Lavender;
            this.btn_register.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_register.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_register.Location = new System.Drawing.Point(12, 139);
            this.btn_register.Name = "btn_register";
            this.btn_register.Size = new System.Drawing.Size(147, 47);
            this.btn_register.TabIndex = 29;
            this.btn_register.Text = "REGISTER";
            this.btn_register.UseVisualStyleBackColor = false;
            this.btn_register.Click += new System.EventHandler(this.btn_register_Click);
            // 
            // btn_update
            // 
            this.btn_update.BackColor = System.Drawing.Color.Lavender;
            this.btn_update.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_update.Location = new System.Drawing.Point(12, 397);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(147, 47);
            this.btn_update.TabIndex = 28;
            this.btn_update.Text = "UPDATE";
            this.btn_update.UseVisualStyleBackColor = false;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_display
            // 
            this.btn_display.BackColor = System.Drawing.Color.Lavender;
            this.btn_display.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_display.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_display.Location = new System.Drawing.Point(12, 334);
            this.btn_display.Name = "btn_display";
            this.btn_display.Size = new System.Drawing.Size(147, 47);
            this.btn_display.TabIndex = 27;
            this.btn_display.Text = "DISPLAY";
            this.btn_display.UseVisualStyleBackColor = false;
            this.btn_display.Click += new System.EventHandler(this.btn_display_Click);
            // 
            // btn_wage
            // 
            this.btn_wage.BackColor = System.Drawing.Color.Lavender;
            this.btn_wage.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_wage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_wage.Location = new System.Drawing.Point(12, 268);
            this.btn_wage.Name = "btn_wage";
            this.btn_wage.Size = new System.Drawing.Size(147, 47);
            this.btn_wage.TabIndex = 26;
            this.btn_wage.Text = "WAGES";
            this.btn_wage.UseVisualStyleBackColor = false;
            this.btn_wage.Click += new System.EventHandler(this.btn_wage_Click);
            // 
            // btn_search
            // 
            this.btn_search.BackColor = System.Drawing.Color.Lavender;
            this.btn_search.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_search.Location = new System.Drawing.Point(12, 76);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(147, 47);
            this.btn_search.TabIndex = 25;
            this.btn_search.Text = "SEARCH";
            this.btn_search.UseVisualStyleBackColor = false;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // btn_home
            // 
            this.btn_home.BackColor = System.Drawing.Color.Lavender;
            this.btn_home.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_home.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_home.Location = new System.Drawing.Point(12, 12);
            this.btn_home.Name = "btn_home";
            this.btn_home.Size = new System.Drawing.Size(147, 47);
            this.btn_home.TabIndex = 24;
            this.btn_home.Text = "HOME";
            this.btn_home.UseVisualStyleBackColor = false;
            this.btn_home.Click += new System.EventHandler(this.btn_home_Click);
            // 
            // btn_gallery
            // 
            this.btn_gallery.BackColor = System.Drawing.Color.Lavender;
            this.btn_gallery.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_gallery.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_gallery.Location = new System.Drawing.Point(12, 522);
            this.btn_gallery.Name = "btn_gallery";
            this.btn_gallery.Size = new System.Drawing.Size(147, 47);
            this.btn_gallery.TabIndex = 32;
            this.btn_gallery.Text = "GALLERY";
            this.btn_gallery.UseVisualStyleBackColor = false;
            this.btn_gallery.Click += new System.EventHandler(this.btn_gallery_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(485, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(388, 30);
            this.label2.TabIndex = 34;
            this.label2.Text = "Beauty Lies Within You...";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("MV Boli", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Purple;
            this.label1.Location = new System.Drawing.Point(463, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(662, 105);
            this.label1.TabIndex = 33;
            this.label1.Text = "COCO Cosmetics";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.link_show2);
            this.panel1.Controls.Add(this.link_show);
            this.panel1.Controls.Add(this.btn_sign);
            this.panel1.Controls.Add(this.lbl_user);
            this.panel1.Controls.Add(this.btn_log);
            this.panel1.Controls.Add(this.txt_user);
            this.panel1.Controls.Add(this.txt_confirm);
            this.panel1.Controls.Add(this.txt_pswd);
            this.panel1.Controls.Add(this.lbl_confirm);
            this.panel1.Controls.Add(this.lbl_pswd);
            this.panel1.Location = new System.Drawing.Point(325, 164);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(631, 369);
            this.panel1.TabIndex = 43;
            // 
            // link_show
            // 
            this.link_show.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.link_show.AutoSize = true;
            this.link_show.BackColor = System.Drawing.Color.Transparent;
            this.link_show.DisabledLinkColor = System.Drawing.Color.Transparent;
            this.link_show.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.link_show.LinkColor = System.Drawing.Color.White;
            this.link_show.Location = new System.Drawing.Point(521, 118);
            this.link_show.Name = "link_show";
            this.link_show.Size = new System.Drawing.Size(54, 20);
            this.link_show.TabIndex = 52;
            this.link_show.TabStop = true;
            this.link_show.Text = "Show";
            this.link_show.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.link_show_LinkClicked);
            // 
            // btn_sign
            // 
            this.btn_sign.BackColor = System.Drawing.Color.Lavender;
            this.btn_sign.Font = new System.Drawing.Font("Microsoft PhagsPa", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_sign.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_sign.Location = new System.Drawing.Point(70, 261);
            this.btn_sign.Name = "btn_sign";
            this.btn_sign.Size = new System.Drawing.Size(147, 47);
            this.btn_sign.TabIndex = 51;
            this.btn_sign.Text = "Sign Up";
            this.btn_sign.UseVisualStyleBackColor = false;
            // 
            // lbl_user
            // 
            this.lbl_user.AutoSize = true;
            this.lbl_user.BackColor = System.Drawing.Color.Transparent;
            this.lbl_user.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_user.ForeColor = System.Drawing.SystemColors.Control;
            this.lbl_user.Location = new System.Drawing.Point(67, 60);
            this.lbl_user.Name = "lbl_user";
            this.lbl_user.Size = new System.Drawing.Size(108, 27);
            this.lbl_user.TabIndex = 46;
            this.lbl_user.Text = "Username";
            // 
            // btn_log
            // 
            this.btn_log.BackColor = System.Drawing.Color.Lavender;
            this.btn_log.Font = new System.Drawing.Font("Microsoft PhagsPa", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_log.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_log.Location = new System.Drawing.Point(306, 261);
            this.btn_log.Name = "btn_log";
            this.btn_log.Size = new System.Drawing.Size(257, 47);
            this.btn_log.TabIndex = 50;
            this.btn_log.Text = "Already a member? Log In";
            this.btn_log.UseVisualStyleBackColor = false;
            // 
            // txt_user
            // 
            this.txt_user.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_user.Location = new System.Drawing.Point(274, 60);
            this.txt_user.Name = "txt_user";
            this.txt_user.Size = new System.Drawing.Size(289, 34);
            this.txt_user.TabIndex = 44;
            // 
            // txt_confirm
            // 
            this.txt_confirm.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_confirm.Location = new System.Drawing.Point(274, 164);
            this.txt_confirm.Name = "txt_confirm";
            this.txt_confirm.PasswordChar = '*';
            this.txt_confirm.Size = new System.Drawing.Size(241, 34);
            this.txt_confirm.TabIndex = 49;
            // 
            // txt_pswd
            // 
            this.txt_pswd.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_pswd.Location = new System.Drawing.Point(274, 112);
            this.txt_pswd.Name = "txt_pswd";
            this.txt_pswd.PasswordChar = '*';
            this.txt_pswd.Size = new System.Drawing.Size(241, 34);
            this.txt_pswd.TabIndex = 45;
            // 
            // lbl_confirm
            // 
            this.lbl_confirm.AutoSize = true;
            this.lbl_confirm.BackColor = System.Drawing.Color.Transparent;
            this.lbl_confirm.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_confirm.ForeColor = System.Drawing.SystemColors.Control;
            this.lbl_confirm.Location = new System.Drawing.Point(67, 164);
            this.lbl_confirm.Name = "lbl_confirm";
            this.lbl_confirm.Size = new System.Drawing.Size(186, 27);
            this.lbl_confirm.TabIndex = 48;
            this.lbl_confirm.Text = "Confirm Password";
            // 
            // lbl_pswd
            // 
            this.lbl_pswd.AutoSize = true;
            this.lbl_pswd.BackColor = System.Drawing.Color.Transparent;
            this.lbl_pswd.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pswd.ForeColor = System.Drawing.SystemColors.Control;
            this.lbl_pswd.Location = new System.Drawing.Point(67, 112);
            this.lbl_pswd.Name = "lbl_pswd";
            this.lbl_pswd.Size = new System.Drawing.Size(103, 27);
            this.lbl_pswd.TabIndex = 47;
            this.lbl_pswd.Text = "Password";
            // 
            // link_show2
            // 
            this.link_show2.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.link_show2.AutoSize = true;
            this.link_show2.BackColor = System.Drawing.Color.Transparent;
            this.link_show2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.link_show2.LinkColor = System.Drawing.Color.White;
            this.link_show2.Location = new System.Drawing.Point(522, 172);
            this.link_show2.Name = "link_show2";
            this.link_show2.Size = new System.Drawing.Size(54, 20);
            this.link_show2.TabIndex = 53;
            this.link_show2.TabStop = true;
            this.link_show2.Text = "Show";
            this.link_show2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.link_show2_LinkClicked);
            // 
            // SIGNUP
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1149, 585);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_gallery);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.btn_register);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_display);
            this.Controls.Add(this.btn_wage);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.btn_home);
            this.Name = "SIGNUP";
            this.Text = "SIGNUP";
            this.Load += new System.EventHandler(this.SIGNUP_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button btn_register;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_display;
        private System.Windows.Forms.Button btn_wage;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Button btn_home;
        private System.Windows.Forms.Button btn_gallery;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_sign;
        private System.Windows.Forms.Label lbl_user;
        private System.Windows.Forms.Button btn_log;
        private System.Windows.Forms.TextBox txt_user;
        private System.Windows.Forms.TextBox txt_confirm;
        private System.Windows.Forms.TextBox txt_pswd;
        private System.Windows.Forms.Label lbl_confirm;
        private System.Windows.Forms.Label lbl_pswd;
        private System.Windows.Forms.LinkLabel link_show;
        private System.Windows.Forms.LinkLabel link_show2;
    }
}