﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace COCO
{
    public partial class SIGNUP : Form
    {
        public SIGNUP()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;

        private void SIGNUP_Load(object sender, EventArgs e)
        {
            panel1.BackColor = Color.FromArgb(100,0,0,0);
            btn_sign.Click += btn_sign_Click;
            btn_log.Click += btn_log_Click;

            con = new SqlConnection("Data Source=desktop-g85uqsh;Initial Catalog=COCO;Integrated Security=True");
            con.Open();
        }
        private void btn_home_Click(object sender, EventArgs e)
        {
            HOME_PAGE obj = new HOME_PAGE();
            obj.Show();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DELETE obj = new DELETE();
            obj.Show();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            LOGIN obj = new LOGIN();
            obj.Show();
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            REGISTRATION obj = new REGISTRATION();
            obj.Show();
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            UPDATE obj = new UPDATE();
            obj.Show();
        }

        private void btn_display_Click(object sender, EventArgs e)
        {
            DISPLAY obj = new DISPLAY();
            obj.Show();
        }

        private void btn_wage_Click(object sender, EventArgs e)
        {
            WAGE obj = new WAGE();
            obj.Show();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            SEARCH obj = new SEARCH();
            obj.Show();
        }

        private void btn_gallery_Click(object sender, EventArgs e)
        {
            GALLERY obj = new GALLERY();
            obj.Show();
        }

        private void btn_log_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Button Clicked");
            try
            {
                this.Hide();
                LOGIN obj = new LOGIN();
                obj.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_sign_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Button Clicked");
            try
            {
                if (txt_confirm.Text != string.Empty || txt_pswd.Text != string.Empty || txt_user.Text != string.Empty)
                {
                    if (txt_pswd.Text == txt_confirm.Text)
                    {
                        cmd = new SqlCommand("select * from SignUp where Username = @Username", con);
                        cmd.Parameters.AddWithValue("@Username", txt_user.Text);
                        dr = cmd.ExecuteReader();
                        if (dr.Read())
                        {
                            dr.Close();
                            MessageBox.Show("Username Already exist please try another ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            dr.Close();
                            cmd = new SqlCommand("Insert into SignUp values (@Username,@User_Password)", con);
                            cmd.Parameters.AddWithValue("@Username", txt_user.Text);
                            cmd.Parameters.AddWithValue("@User_Password", txt_pswd.Text);
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Your Account is created. Please login now.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Passwords do not match.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please fill all the fields", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void link_show_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if(link_show.Text == "Show")
            {
                txt_pswd.PasswordChar = '\0';
                link_show.Text = "Hide";
            }
            else
            {
                txt_pswd.PasswordChar = '*';
                link_show.Text = "Show";
            }
        }

        private void link_show2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (link_show2.Text == "Show")
            {
                txt_confirm.PasswordChar = '\0';
                link_show2.Text = "Hide";
            }
            else
            {
                txt_confirm.PasswordChar = '*';
                link_show2.Text = "Show";
            }
        }
    }
}
