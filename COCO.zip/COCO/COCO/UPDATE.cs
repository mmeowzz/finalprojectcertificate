﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace COCO
{
    public partial class UPDATE : Form
    {
        public UPDATE()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlDataAdapter da;

        private void btn_home_Click(object sender, EventArgs e)
        {
            HOME_PAGE obj = new HOME_PAGE();
            obj.Show();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            SEARCH obj = new SEARCH();
            obj.Show();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            LOGIN obj = new LOGIN();
            obj.Show();
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            REGISTRATION obj = new REGISTRATION();
            obj.Show();
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            UPDATE obj = new UPDATE();
            obj.Show();
        }

        private void btn_display_Click(object sender, EventArgs e)
        {
            DISPLAY obj = new DISPLAY();
            obj.Show();
        }

        private void btn_wage_Click(object sender, EventArgs e)
        {
            WAGE obj = new WAGE();
            obj.Show();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DELETE obj = new DELETE();
            obj.Show();
        }

        private void btn_gallery_Click(object sender, EventArgs e)
        {
            GALLERY obj = new GALLERY();
            obj.Show();
        }

        private void UPDATE_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=desktop-g85uqsh;Initial Catalog=COCO;Integrated Security=True");
        }

        private void btn_up_Click(object sender, EventArgs e)
        {
            string ConnectionString = "Data Source=desktop-g85uqsh;Initial Catalog=COCO;Integrated Security=True";
            SqlConnection con = new SqlConnection(ConnectionString);
            
            con.Open();
            string ID = txt_id.Text;
            string Name = txt_name.Text;
            string NIC = txt_nic.Text;
            string GenderM = rbtn_male.Text;
            string GenderF = rbtn_female.Text;
            string Address = txt_address.Text;
            string DOB = datetimepicker.Text;
            string Age = txt_age.Text;
            string Contact = txt_contact.Text;
            string Position = cmb_job.Text;
            string Email = txt_email.Text;

            string g;
            if (rbtn_male.Checked == true)
            {
                g = "Male";
            }
            else
            {
                g = "Female";
            }

            string Query = "Update Register set " +
                "Employee_Name = '" + txt_name.Text + "', " +
                "EMployee_NIC = '" + txt_nic.Text + "', " +
                "Employee_Gender = '" + g + "', " +
                "Employee_Address = '" + txt_address.Text + "', " +
                "Employee_DOB = '" + datetimepicker.Value + "'," +
                "Employee_Age = '" + txt_age.Text + "', " +
                "Employee_ContactNumber = '" + txt_contact.Text + "', " +
                "Employee_Position = '" + cmb_job.SelectedItem + "', " +
                "Employee_Email = '" + txt_email.Text + "' where Employee_ID = '"+txt_id.Text+"'";
            SqlCommand cmd = new SqlCommand(Query, con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Data updated successfully.","Information",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }

        private void datetimepicker_ValueChanged(object sender, EventArgs e)
        {
            int age = DateTime.Now.Year - datetimepicker.Value.Year;
            txt_age.Text = age.ToString();
        }

        private void btn_dis_Click(object sender, EventArgs e)
        {
            con.Open();
            da = new SqlDataAdapter("select * from Register", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            display_data.DataSource = dt;
            con.Close();
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_name.Clear();
            txt_nic.Clear();
            rbtn_male.Checked = false;
            rbtn_female.Checked = false;
            txt_address.Clear();
            datetimepicker.ResetText();
            txt_age.Clear();
            txt_contact.Clear();
            cmb_job.SelectedIndex = -1;
            txt_email.Clear();
        }
    }
}
