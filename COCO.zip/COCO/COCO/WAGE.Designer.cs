﻿namespace COCO
{
    partial class WAGE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_login = new System.Windows.Forms.Button();
            this.btn_register = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_display = new System.Windows.Forms.Button();
            this.btn_wage = new System.Windows.Forms.Button();
            this.btn_search = new System.Windows.Forms.Button();
            this.btn_home = new System.Windows.Forms.Button();
            this.btn_gallery = new System.Windows.Forms.Button();
            this.lbl_job = new System.Windows.Forms.Label();
            this.btn_basic = new System.Windows.Forms.Label();
            this.lbl_allow = new System.Windows.Forms.Label();
            this.lbl_med = new System.Windows.Forms.Label();
            this.lbl_tot = new System.Windows.Forms.Label();
            this.txt_basic = new System.Windows.Forms.TextBox();
            this.txt_allow = new System.Windows.Forms.TextBox();
            this.txt_med = new System.Windows.Forms.TextBox();
            this.txt_tot = new System.Windows.Forms.TextBox();
            this.txt_net = new System.Windows.Forms.TextBox();
            this.lbl_net = new System.Windows.Forms.Label();
            this.cmb_job = new System.Windows.Forms.ComboBox();
            this.btn_cal = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.lbl_auto = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.Color.Lavender;
            this.btn_delete.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_delete.Location = new System.Drawing.Point(12, 460);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(147, 47);
            this.btn_delete.TabIndex = 23;
            this.btn_delete.Text = "DELETE";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_login
            // 
            this.btn_login.BackColor = System.Drawing.Color.Lavender;
            this.btn_login.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_login.Location = new System.Drawing.Point(12, 202);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(147, 47);
            this.btn_login.TabIndex = 21;
            this.btn_login.Text = "LOGIN";
            this.btn_login.UseVisualStyleBackColor = false;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // btn_register
            // 
            this.btn_register.BackColor = System.Drawing.Color.Lavender;
            this.btn_register.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_register.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_register.Location = new System.Drawing.Point(12, 137);
            this.btn_register.Name = "btn_register";
            this.btn_register.Size = new System.Drawing.Size(147, 47);
            this.btn_register.TabIndex = 20;
            this.btn_register.Text = "REGISTER";
            this.btn_register.UseVisualStyleBackColor = false;
            this.btn_register.Click += new System.EventHandler(this.btn_register_Click);
            // 
            // btn_update
            // 
            this.btn_update.BackColor = System.Drawing.Color.Lavender;
            this.btn_update.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_update.Location = new System.Drawing.Point(12, 395);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(147, 47);
            this.btn_update.TabIndex = 19;
            this.btn_update.Text = "UPDATE";
            this.btn_update.UseVisualStyleBackColor = false;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_display
            // 
            this.btn_display.BackColor = System.Drawing.Color.Lavender;
            this.btn_display.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_display.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_display.Location = new System.Drawing.Point(12, 332);
            this.btn_display.Name = "btn_display";
            this.btn_display.Size = new System.Drawing.Size(147, 47);
            this.btn_display.TabIndex = 18;
            this.btn_display.Text = "DISPLAY";
            this.btn_display.UseVisualStyleBackColor = false;
            this.btn_display.Click += new System.EventHandler(this.btn_display_Click);
            // 
            // btn_wage
            // 
            this.btn_wage.BackColor = System.Drawing.Color.Lavender;
            this.btn_wage.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_wage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_wage.Location = new System.Drawing.Point(12, 266);
            this.btn_wage.Name = "btn_wage";
            this.btn_wage.Size = new System.Drawing.Size(147, 47);
            this.btn_wage.TabIndex = 17;
            this.btn_wage.Text = "WAGES";
            this.btn_wage.UseVisualStyleBackColor = false;
            this.btn_wage.Click += new System.EventHandler(this.btn_wage_Click);
            // 
            // btn_search
            // 
            this.btn_search.BackColor = System.Drawing.Color.Lavender;
            this.btn_search.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_search.Location = new System.Drawing.Point(12, 74);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(147, 47);
            this.btn_search.TabIndex = 16;
            this.btn_search.Text = "SEARCH";
            this.btn_search.UseVisualStyleBackColor = false;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // btn_home
            // 
            this.btn_home.BackColor = System.Drawing.Color.Lavender;
            this.btn_home.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_home.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_home.Location = new System.Drawing.Point(12, 12);
            this.btn_home.Name = "btn_home";
            this.btn_home.Size = new System.Drawing.Size(147, 47);
            this.btn_home.TabIndex = 15;
            this.btn_home.Text = "HOME";
            this.btn_home.UseVisualStyleBackColor = false;
            this.btn_home.Click += new System.EventHandler(this.btn_home_Click);
            // 
            // btn_gallery
            // 
            this.btn_gallery.BackColor = System.Drawing.Color.Lavender;
            this.btn_gallery.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_gallery.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_gallery.Location = new System.Drawing.Point(12, 523);
            this.btn_gallery.Name = "btn_gallery";
            this.btn_gallery.Size = new System.Drawing.Size(147, 47);
            this.btn_gallery.TabIndex = 33;
            this.btn_gallery.Text = "GALLERY";
            this.btn_gallery.UseVisualStyleBackColor = false;
            this.btn_gallery.Click += new System.EventHandler(this.btn_gallery_Click);
            // 
            // lbl_job
            // 
            this.lbl_job.AutoSize = true;
            this.lbl_job.Font = new System.Drawing.Font("MingLiU-ExtB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_job.Location = new System.Drawing.Point(244, 57);
            this.lbl_job.Name = "lbl_job";
            this.lbl_job.Size = new System.Drawing.Size(190, 23);
            this.lbl_job.TabIndex = 34;
            this.lbl_job.Text = "Job Description";
            // 
            // btn_basic
            // 
            this.btn_basic.AutoSize = true;
            this.btn_basic.Font = new System.Drawing.Font("MingLiU-ExtB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_basic.Location = new System.Drawing.Point(244, 137);
            this.btn_basic.Name = "btn_basic";
            this.btn_basic.Size = new System.Drawing.Size(154, 23);
            this.btn_basic.TabIndex = 35;
            this.btn_basic.Text = "Basic Salary";
            // 
            // lbl_allow
            // 
            this.lbl_allow.AutoSize = true;
            this.lbl_allow.Font = new System.Drawing.Font("MingLiU-ExtB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_allow.Location = new System.Drawing.Point(244, 216);
            this.lbl_allow.Name = "lbl_allow";
            this.lbl_allow.Size = new System.Drawing.Size(118, 23);
            this.lbl_allow.TabIndex = 36;
            this.lbl_allow.Text = "Allowance";
            // 
            // lbl_med
            // 
            this.lbl_med.AutoSize = true;
            this.lbl_med.Font = new System.Drawing.Font("MingLiU-ExtB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_med.Location = new System.Drawing.Point(244, 290);
            this.lbl_med.Name = "lbl_med";
            this.lbl_med.Size = new System.Drawing.Size(214, 23);
            this.lbl_med.TabIndex = 37;
            this.lbl_med.Text = "Medical Allowance";
            // 
            // lbl_tot
            // 
            this.lbl_tot.AutoSize = true;
            this.lbl_tot.Font = new System.Drawing.Font("MingLiU-ExtB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tot.Location = new System.Drawing.Point(244, 364);
            this.lbl_tot.Name = "lbl_tot";
            this.lbl_tot.Size = new System.Drawing.Size(154, 23);
            this.lbl_tot.TabIndex = 38;
            this.lbl_tot.Text = "Total Salary";
            // 
            // txt_basic
            // 
            this.txt_basic.Font = new System.Drawing.Font("MingLiU-ExtB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_basic.Location = new System.Drawing.Point(504, 137);
            this.txt_basic.Name = "txt_basic";
            this.txt_basic.ReadOnly = true;
            this.txt_basic.Size = new System.Drawing.Size(297, 35);
            this.txt_basic.TabIndex = 39;
            // 
            // txt_allow
            // 
            this.txt_allow.Font = new System.Drawing.Font("MingLiU-ExtB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_allow.Location = new System.Drawing.Point(504, 216);
            this.txt_allow.Name = "txt_allow";
            this.txt_allow.ReadOnly = true;
            this.txt_allow.Size = new System.Drawing.Size(297, 35);
            this.txt_allow.TabIndex = 40;
            // 
            // txt_med
            // 
            this.txt_med.Font = new System.Drawing.Font("MingLiU-ExtB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_med.Location = new System.Drawing.Point(504, 290);
            this.txt_med.Name = "txt_med";
            this.txt_med.ReadOnly = true;
            this.txt_med.Size = new System.Drawing.Size(297, 35);
            this.txt_med.TabIndex = 41;
            // 
            // txt_tot
            // 
            this.txt_tot.Font = new System.Drawing.Font("MingLiU-ExtB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tot.Location = new System.Drawing.Point(504, 364);
            this.txt_tot.Name = "txt_tot";
            this.txt_tot.ReadOnly = true;
            this.txt_tot.Size = new System.Drawing.Size(297, 35);
            this.txt_tot.TabIndex = 42;
            // 
            // txt_net
            // 
            this.txt_net.Font = new System.Drawing.Font("MingLiU-ExtB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_net.Location = new System.Drawing.Point(504, 443);
            this.txt_net.Name = "txt_net";
            this.txt_net.ReadOnly = true;
            this.txt_net.Size = new System.Drawing.Size(297, 35);
            this.txt_net.TabIndex = 43;
            // 
            // lbl_net
            // 
            this.lbl_net.AutoSize = true;
            this.lbl_net.Font = new System.Drawing.Font("MingLiU-ExtB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_net.Location = new System.Drawing.Point(244, 443);
            this.lbl_net.Name = "lbl_net";
            this.lbl_net.Size = new System.Drawing.Size(130, 23);
            this.lbl_net.TabIndex = 44;
            this.lbl_net.Text = "Net Salary";
            // 
            // cmb_job
            // 
            this.cmb_job.FormattingEnabled = true;
            this.cmb_job.Items.AddRange(new object[] {
            "Marketing",
            "Finance",
            "Sales Representative",
            "Crew Member",
            "IT Specialist"});
            this.cmb_job.Location = new System.Drawing.Point(504, 57);
            this.cmb_job.Name = "cmb_job";
            this.cmb_job.Size = new System.Drawing.Size(296, 31);
            this.cmb_job.TabIndex = 45;
            this.cmb_job.SelectedIndexChanged += new System.EventHandler(this.cmb_job_SelectedIndexChanged);
            // 
            // btn_cal
            // 
            this.btn_cal.BackColor = System.Drawing.Color.Lavender;
            this.btn_cal.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_cal.Location = new System.Drawing.Point(299, 523);
            this.btn_cal.Name = "btn_cal";
            this.btn_cal.Size = new System.Drawing.Size(147, 47);
            this.btn_cal.TabIndex = 46;
            this.btn_cal.Text = "CALCULATE";
            this.btn_cal.UseVisualStyleBackColor = false;
            this.btn_cal.Click += new System.EventHandler(this.btn_cal_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.BackColor = System.Drawing.Color.Lavender;
            this.btn_clear.Font = new System.Drawing.Font("Mistral", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_clear.Location = new System.Drawing.Point(593, 523);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(147, 47);
            this.btn_clear.TabIndex = 47;
            this.btn_clear.Text = "CLEAR";
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // lbl_auto
            // 
            this.lbl_auto.AutoSize = true;
            this.lbl_auto.BackColor = System.Drawing.Color.Transparent;
            this.lbl_auto.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_auto.Location = new System.Drawing.Point(650, 12);
            this.lbl_auto.Name = "lbl_auto";
            this.lbl_auto.Size = new System.Drawing.Size(266, 16);
            this.lbl_auto.TabIndex = 55;
            this.lbl_auto.Text = "*Select \'Job Description\' and click \'Calculate\'.";
            // 
            // WAGE
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(926, 592);
            this.Controls.Add(this.lbl_auto);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_cal);
            this.Controls.Add(this.cmb_job);
            this.Controls.Add(this.lbl_net);
            this.Controls.Add(this.txt_net);
            this.Controls.Add(this.txt_tot);
            this.Controls.Add(this.txt_med);
            this.Controls.Add(this.txt_allow);
            this.Controls.Add(this.txt_basic);
            this.Controls.Add(this.lbl_tot);
            this.Controls.Add(this.lbl_med);
            this.Controls.Add(this.lbl_allow);
            this.Controls.Add(this.btn_basic);
            this.Controls.Add(this.lbl_job);
            this.Controls.Add(this.btn_gallery);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.btn_register);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_display);
            this.Controls.Add(this.btn_wage);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.btn_home);
            this.Font = new System.Drawing.Font("MingLiU-ExtB", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "WAGE";
            this.Text = "WAGE";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button btn_register;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_display;
        private System.Windows.Forms.Button btn_wage;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Button btn_home;
        private System.Windows.Forms.Button btn_gallery;
        private System.Windows.Forms.Label lbl_job;
        private System.Windows.Forms.Label btn_basic;
        private System.Windows.Forms.Label lbl_allow;
        private System.Windows.Forms.Label lbl_med;
        private System.Windows.Forms.Label lbl_tot;
        private System.Windows.Forms.TextBox txt_basic;
        private System.Windows.Forms.TextBox txt_allow;
        private System.Windows.Forms.TextBox txt_med;
        private System.Windows.Forms.TextBox txt_tot;
        private System.Windows.Forms.TextBox txt_net;
        private System.Windows.Forms.Label lbl_net;
        private System.Windows.Forms.ComboBox cmb_job;
        private System.Windows.Forms.Button btn_cal;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Label lbl_auto;
    }
}