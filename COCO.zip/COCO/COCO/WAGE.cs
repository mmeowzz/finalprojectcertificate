﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COCO
{
    public partial class WAGE : Form
    {
        public WAGE()
        {
            InitializeComponent();
        }

        private void btn_home_Click(object sender, EventArgs e)
        {
            HOME_PAGE obj = new HOME_PAGE();
            obj.Show();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DELETE obj = new DELETE();
            obj.Show();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            LOGIN obj = new LOGIN();
            obj.Show();
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            REGISTRATION obj = new REGISTRATION();
            obj.Show();
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            DISPLAY obj = new DISPLAY();
            obj.Show();
        }

        private void btn_display_Click(object sender, EventArgs e)
        {
            DISPLAY obj = new DISPLAY();
            obj.Show();
        }

        private void btn_wage_Click(object sender, EventArgs e)
        {
            WAGE obj = new WAGE();
            obj.Show();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            SEARCH obj = new SEARCH();
            obj.Show();
        }

        private void btn_gallery_Click(object sender, EventArgs e)
        {
            GALLERY obj = new GALLERY();
            obj.Show();
        }

        private void cmb_job_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void btn_cal_Click(object sender, EventArgs e)
        {
            double basic;
            if (cmb_job.SelectedIndex == 0)//Marketing
                basic = 500000;
            else if (cmb_job.SelectedIndex == 1)//Finance
                basic = 300000;
            else if (cmb_job.SelectedIndex == 2)//Sales Representative
                basic = 80000;
            else if (cmb_job.SelectedIndex == 3)//Crew Member
                basic = 200000;
            else
                basic = 400000;
            txt_basic.Text = basic.ToString();

            double allow = 20000;
            txt_allow.Text = allow.ToString();

            double medical = 25000;
            txt_med.Text = medical.ToString();

            double tot;
            tot = basic + allow + medical;
            txt_tot.Text = tot.ToString();

            double tax = tot * 0.05;
            double epf = basic * 0.1;
            double etf = basic * 0.03;

            double net = tot - epf - etf - tax;
            txt_net.Text = net.ToString();
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            cmb_job.SelectedIndex = -1;
            txt_basic.Clear();
            txt_allow.Clear();
            txt_med.Clear();
            txt_tot.Clear();
            txt_net.Clear();
        }
    }
}
